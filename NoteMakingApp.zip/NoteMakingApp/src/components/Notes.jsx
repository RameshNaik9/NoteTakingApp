import React from "react";

function Notes() {
  return (
    <div className="note">
      <h1>This is react Bootcamp</h1>
      <p>
        Great Careers start with the best Mentors, and DevTown is the one-stop
        destination to add value to your learning 💯.
      </p>
    </div>
  );
}

export default Notes;
